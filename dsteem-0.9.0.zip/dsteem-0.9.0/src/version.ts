// overwritten by buildscript
export default require('./../package.json').version as string
