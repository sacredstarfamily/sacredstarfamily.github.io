
vote-vot
========

Simple steemit copycat votebot.

Usage
-----

```
FOLLOW_USER=epic-curator BOT_USER=sheepbot POSTING_KEY=5lalalalalalallalala node bot.js
```
