
dsteem comment feed example
===========================

Running on: <https://comments.steem.vc>


Developing
----------

Download and install [node.js](https://nodejs.org).

Download or clone this repository then run:

```
npm install
```

Start the preview server by running:

```
npm run preview
```

Now a local version is running on http://localhost:8080


Deploying
---------

```
npm run build
```

Static output will be in the `build/` folder ready to be copied to a webserver.

---


Built with [Wintersmith](https://github.com/jnordberg/wintersmith).
